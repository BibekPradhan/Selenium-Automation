package bibekproject;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class hahaha {

	@SuppressWarnings("deprecation")
	public static void main(String[] args) {
		// TODO Auto-generated method stub

 ChromeDriver driver = new ChromeDriver();
 driver.get("https://qa-enroll.purenroll.com/");
 driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
 driver.findElement(By.xpath("/html/body/div[3]/div[2]/section/div[1]/div/div[2]/div[1]/div/form/div[1]/input")).sendKeys("12345");
 driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
 driver.findElement(By.xpath("/html/body/div[3]/div[2]/section/div[1]/div/div[2]/div[1]/div/form/div[2]/button")).click();
 driver.findElement(By.xpath("/html/body/div[3]/div[2]/section/div[1]/div/div[2]/div[1]/div/form/div[1]/span/input")).sendKeys("07/07/1999");
 driver.findElement(By.xpath("/html/body/div[3]/div[2]/section/div[1]/div/div[2]/div[1]/div/form/div[2]/button[2]")).click();
//dropdowns
 Select drpclk= new Select(driver.findElement(By.xpath("/html/body/div[3]/div[2]/section/div[1]/div/div[2]/div[1]/div/form/div[1]/div/select")));
 drpclk.selectByVisibleText("Male");
 driver.findElement(By.xpath("/html/body/div[3]/div[2]/section/div[1]/div/div[2]/div[1]/div/form/div[2]/button[2]")).click();
 
 Select dropclk= new Select(driver.findElement(By.xpath("/html/body/div[3]/div[2]/section/div[1]/div/div[2]/div[1]/div/form/div[1]/select")));
 dropclk.selectByVisibleText("Member Only");
 driver.findElement(By.xpath("/html/body/div[3]/div[2]/section/div[1]/div/div[2]/div[1]/div/form/div[2]/button[2]")).click();
	
 Select dopclick= new Select(driver.findElement(By.xpath("/html/body/div[3]/div[2]/section/div[1]/div/div[2]/div[1]/div/form/div[1]/div/div[1]")));
 dopclick.selectByVisibleText("Rx");
 driver.findElement(By.xpath("/html/body/div[3]/div[2]/section/div[1]/div/div[2]/div[1]/div/form/div[2]/button[2]")).click();
 
 Select dpclk=new Select(driver.findElement(By.xpath("/html/body/div[3]/div[2]/section/div[1]/div/div[2]/div[1]/div/form/div[1]/select")));
 dpclk.selectByVisibleText("Prescription");
 driver.findElement(By.xpath("/html/body/div[3]/div[2]/section/div[1]/div/div[2]/div[1]/div/form/div[2]/button[2]"));
	
 //details of plans
 
 driver.findElement(By.xpath("/html/body/div[3]/div[2]/section/section/div[1]/div[2]/div/div/div/div/a")).click();
 
 //addtocart
 driver.findElement(By.xpath("/html/body/div[3]/div[2]/section/section/div/div/div[2]/div[6]/div/div/div[2]/div/div/div/div[3]/button")).click();
 driver.findElement(By.xpath("/html/body/div[3]/div[2]/section/div/div[1]/div[4]/div/a")).click();
 driver.findElement(By.xpath("/html/body/div[6]/div[1]/div/div/div/div/section/div/div[2]/div/button[2]")).click();
	
//personalinfo
 driver.findElement(By.xpath("/html/body/div[3]/div[2]/div/section[2]/div/div[2]/form/div[1]/div[1]/input")).sendKeys("tester");
 driver.findElement(By.xpath("/html/body/div[3]/div[2]/div/section[2]/div/div[2]/form/div[1]/div[3]/input")).sendKeys("tester");
 Select dppclk=new Select(driver.findElement(By.xpath("/html/body/div[3]/div[2]/div/section[2]/div/div[2]/form/div[3]/div[1]/select")));
 dppclk.selectByVisibleText("Single");
 driver.findElement(By.xpath("/html/body/div[3]/div[2]/div/section[2]/div/div[2]/form/div[3]/div[2]/input")).sendKeys("345678910");
 driver.findElement(By.xpath("/html/body/div[3]/div[2]/div/section[2]/div/div[3]/div/button")).click();
 
 //contactinfo
 
 driver.findElement(By.xpath("/html/body/div[3]/div[2]/div/section[2]/div/div[2]/form/div[1]/div[1]/input")).sendKeys("tester@gmail.com");
 driver.findElement(By.xpath("/html/body/div[3]/div[2]/div/section[2]/div/div[2]/form/div[1]/div[2]/input")).sendKeys("345678910");
 driver.findElement(By.xpath("/html/body/div[3]/div[2]/div/section[2]/div/div[2]/form/div[1]/div[3]/input")).sendKeys("abs");
 driver.findElement(By.xpath("/html/body/div[3]/div[2]/div/section[2]/div/div[2]/form/div[2]/div[1]/input")).sendKeys("allhj");
 driver.findElement(By.xpath("/html/body/div[3]/div[2]/div/section[2]/div/div[3]/div/a[2]")).click();
 
	}

}
